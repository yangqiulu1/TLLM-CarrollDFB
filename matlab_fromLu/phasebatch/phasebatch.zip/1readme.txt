This is a suite of programs organised by RGS Plumb to illustrate
the power of using a 3 dimensional plot. It uses a standard dfb 
set of programs but lets the facet phases at the high reflectivity
 end of the laser change It is has been tested on
systems with 400 MHz clock system and 128Mb RAM or better using 
Matlab 5 or 6.

Start with the command

phasebatch

and let the system run.
