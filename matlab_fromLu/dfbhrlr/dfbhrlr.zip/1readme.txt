Dated 14th August 2001

This DFB programme suite has a uniform DFB with a mixture of index and gain coupling
It also has one facet with a high reflectivity (0.9) and the other with a low reflectivity (0) as default setting.
This type of laser gives a good single mode performance with a wide range of phases on the reflectivities.
The code is essentially the same as in the dfb suite but with the minor additions that allow for the greater choice of parameters.
Start with program
dfbHRLR